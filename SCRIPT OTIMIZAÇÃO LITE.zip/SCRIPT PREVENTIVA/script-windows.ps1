# Fun��o para limpar o lixo do sistema
function LimparLixo {
    Write-Host "Removendo o bloatware..."
    Get-AppxPackage -Name "Microsoft.WindowsAlarms" | Remove-AppxPackage
    Get-AppxPackage -Name "SpotifyAB.SpotifyMusic" | Remove-AppxPackage
    Get-AppxPackage -Name "Microsoft.549981C3F5F10" | Remove-AppxPackage
    Get-AppxPackage -Name "Microsoft.SkypeApp" | Remove-AppxPackage
    Get-AppxPackage -Name "Microsoft.WindowsFeedbackHub" | Remove-AppxPackage
    Get-AppxPackage -Name "Microsoft.MicrosoftSolitaireCollection" | Remove-AppxPackage
    Get-AppxPackage -Name "Microsoft.WindowsSoundRecorder" | Remove-AppxPackage
    Get-AppxPackage -Name "Microsoft.Microsoft3DViewer" | Remove-AppxPackage
    Get-AppxPackage -Name "Microsoft.XboxGamingOverlay" | Remove-AppxPackage
    Get-AppxPackage -Name "Microsoft.YourPhone" | Remove-AppxPackage
    Get-AppxPackage -Name "Microsoft.ZuneVideo" | Remove-AppxPackage
    Get-AppxPackage -Name "Microsoft.Getstarted" | Remove-AppxPackage
    Get-AppxPackage -Name "WindowsCamera" | Remove-AppxPackage
    Get-AppxPackage -Name "Microsoft.Todos" | Remove-AppxPackage
    Get-AppxPackage -Name "Microsoft.ScreenSketch" | Remove-AppxPackage
    Get-AppxPackage -Name "Microsoft.People" | Remove-AppxPackage
    Get-AppxPackage -Name "Microsoft.GetHelp" | Remove-AppxPackage
    Get-AppxPackage -Name "Microsoft.GamingApp" | Remove-AppxPackage
    Get-AppxPackage -Name "Microsoft.BingWeather" | Remove-AppxPackage
    Get-AppxPackage -Name "Microsoft.BingNews" | Remove-AppxPackage
    Get-AppxPackage -Name "microsoft.WindowsMaps" | Remove-AppxPackage
    Get-AppxPackage -Name "Microsoft.MicrosoftOfficeHub" | Remove-AppxPackage
    Get-AppxPackage -Name "Microsoft.ZuneMusic" | Remove-AppxPackage
    Get-AppxPackage -Name "Spotify.Spotify" | Remove-AppxPackage
    Get-AppxPackage -Name "Skype" | Remove-AppxPackage
    Get-AppxPackage -Name "Microsoft.OneNote" | Remove-AppxPackage
    Get-AppxPackage -Name "Microsoft.Xbox" | Remove-AppxPackage
    Get-AppxPackage -Name "Microsoft.MixedReality.Portal" | Remove-AppxPackage
    Get-AppxPackage -Name "Microsoft.MSPaint" | Remove-AppxPackage
    Get-AppxPackage *xboxapp* | Remove-AppxPackage
    Write-Host "Bloatware removido."

    Write-Host "Limpando a pasta tempor�ria..."
    # Obt�m o caminho da pasta tempor�ria
    $tempPath = [System.IO.Path]::GetTempPath()

    # Obt�m todos os arquivos na pasta tempor�ria
    $tempFiles = Get-ChildItem -Path $tempPath

    # Deleta todos os arquivos
    foreach ($file in $tempFiles) {
        try {
            Remove-Item -Path $file.FullName -Force -Recurse
            Write-Host "Arquivo removido: $($file.FullName)"
        } catch {
            Write-Host "Erro ao remover arquivo: $($file.FullName). $_"
        }
    }

    Write-Host "Pasta tempor�ria limpa."
}

# Fun��o para configurar o DNS
function ConfigurarDNS {
    Get-WmiObject -Class Win32_IP4RouteTable | where { $_.destination -eq '0.0.0.0' -and $_.mask -eq '0.0.0.0'} | Sort-Object metric1 | select interfaceindex | set-DnsClientServerAddress -ServerAddresses ('8.8.8.8', '8.8.4.4')
    Write-Host "DNS configurado."
}

# Fun��o para parar e desabilitar servi�os
function PararDesabilitarServicos {
    $servicos = @("SysMain", "EFS", "WerSvc", "DiagTrack") # Adicione outros servi�os aqui conforme necess�rio

    foreach ($serviceName in $servicos) {
        # Verifica se o servi�o est� em execu��o
        $service = Get-Service -Name $serviceName
        if ($service.Status -eq 'Running') {
            # Para o servi�o
            Stop-Service -Name $serviceName -Force
            Write-Host "O servi�o $serviceName foi parado com sucesso."
        } else {
            Write-Host "O servi�o $serviceName j� est� parado."
        }

        # Define o servi�o para inicializa��o manual
        Set-Service -Name $serviceName -StartupType Manual
        Write-Host "O servi�o $serviceName foi configurado para inicializa��o manual."
    }

    # Desativar o CompatTelRunner via Agendador de Tarefas
    schtasks /Change /TN "\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser" /Disable
    schtasks /Change /TN "\Microsoft\Windows\Application Experience\ProgramDataUpdater" /Disable
    schtasks /Change /TN "\Microsoft\Windows\Application Experience\StartupAppTask" /Disable

    Write-Host "Tarefas de telemetria (coleta de dados da Microsoft) desativadas."
}

# ATUALIZA O WINDOWS
function AtualizarWindows {
    Write-Host "Instalando m�dulos necess�rios..."
    if (-not (Get-Module -ListAvailable -Name PSWindowsUpdate)) {
        Install-Module PSWindowsUpdate -Force
    }

    Write-Host "Atualizando todos os pacotes previamente instalados usando winget..."
    winget upgrade --all

    Write-Host "Importando m�dulo PSWindowsUpdate..."
    Import-Module PSWindowsUpdate

    Write-Host "Definindo pol�tica de execu��o..."
    Set-ExecutionPolicy RemoteSigned -Scope Process -Force

    Write-Host "Verificando e instalando todas as atualiza��es importantes e opcionais..."
    Get-WindowsUpdate -AcceptAll -Install -AutoReboot

    Write-Host "Verificando e instalando todas as atualiza��es opcionais..."
    Get-WindowsUpdate -MicrosoftUpdate -AcceptAll -Install -Category "Optional" -AutoReboot

    Write-Host "Todas as atualiza��es foram instaladas com sucesso."
}



# Chamando as fun��es
LimparLixo
ConfigurarDNS
PararDesabilitarServicos

# Atualizar Windows
AtualizarWindows


Write-Host "Todas as tarefas foram conclu�das."
